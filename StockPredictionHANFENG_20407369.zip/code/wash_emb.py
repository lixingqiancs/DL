import numpy as np
import json

emb = open("../codes_pre_clean/glove.6B.100d.txt", "r", encoding='UTF-8')
line = emb.readline()
word2index = {}
index2vec = []
idx = 0
while line:
    info = line.split()
    word = info[0]
    vec = [float(data) for data in info[1:]]
    word2index[word] = idx
    index2vec.append(np.array(vec))
    idx += 1
    line = emb.readline()
np.save("common.emb_100", np.array(index2vec))
json.dump(word2index, open("word2idx", "w"))
