import numpy as np
import json

x = np.load("THAD6h.x.npy", allow_pickle=True)
index = np.load("THAD6h.idx.npy", allow_pickle=True)[0]
word2idx = json.load(open("word2idx"))
idx2word = {}
for w in word2idx:
    idx2word[word2idx[w]] = w

sad = {"nodes": [], "links": []}
nodes = {}
links = {}
for j in range(2):
    subx = x[0, j]
    for row in range(len(subx.rows)):
        for col_idx in range(len(subx.rows[row])):
            col = subx.rows[row][col_idx]
            nodes[idx2word[index[row]]] = j
            nodes[idx2word[index[col_idx]]] = j
            if (idx2word[index[row]], idx2word[index[col_idx]]) in links:
                links[(idx2word[index[row]], idx2word[index[col_idx]])] += subx.data[row][col_idx]
            else:
                links[(idx2word[index[row]], idx2word[index[col_idx]])] = subx.data[row][col_idx]
            #  sad["links"].append({"source": idx2word[index[row]], "target": idx2word[index[col_idx]],
            #                     "value": subx.data[row][col_idx]})
for edge in links:
    sad["links"].append({"source": edge[0], "target": edge[1], "value": links[edge]})
for node in nodes:
    sad["nodes"].append({"id": node, "group": nodes[node]})
json.dump(sad, open("sad.json", "w"))
