import csv
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import json

ps = PorterStemmer()  # stemmer
stop = set(stopwords.words('english'))
word_all = {}  # the word and its frequency, saved for stop word generation
info = []  # dates*25->words
trump = json.load(open("trump_raw_new.txt", 'r', encoding='UTF-8'))  #
articles = {}
month = [',', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
for i in trump:
    day_i = i['created_at'].strip().split()
    day = day_i[-1]+"-"+str(100+month.index(day_i[1]))[-2:]+"-"+str(int(day_i[2]))
    if day in articles:
        articles[day].append(i['text'])
    else:
        articles[day] = [i['text']]
days = []
label = []
print(articles.keys())
last = 0
with open('DJIA_new.csv')as f:
    f_csv = csv.reader(f)
    flag = True
    counter = 0
    for row in f_csv:
        if flag:
            flag = False
            continue
        date_info = []  # all the articles in a day
        counter += 1
        print(counter)
        day = row[0]
        if day in articles:
            print(day)
            for body in articles[day]:
                article = []  # all the words in an article
                for word in body.strip("b").strip('"').lower().replace('|', '').replace(',', '')\
                        .replace('(', '').replace(')', '').replace(';', '').replace('?', '').replace('[', '')\
                        .replace(']', '').replace('!', '').replace('.', '').replace('-', '').replace('\n', ' ') \
                        .replace(':', '').replace("'", '').split():
                    if word.isdigit() or word in stop:
                        continue
                    word = ps.stem(word)
                    article.append(word)
                    if word not in word_all:
                        word_all[word] = 0
                    word_all[word] += 1
                date_info.append(article)
            info.append(date_info)
            if float(float(row[1]) > last):
                label.append(1)
            else:
                label.append(0)
        if row[1] != '.':
            last = float(row[1])
json.dump(info, open("texts.json", "w"))
json.dump(word_all, open("counter.json", "w"))
json.dump(label, open("label.json", "w"))
