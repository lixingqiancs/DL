import json
import numpy as np
import scipy.sparse as sp
counter = json.load(open("counter.json"))
frequent = list(counter.values())
frequent.sort()
print(len(frequent))
thr_h = frequent[-1]+1  # frequent[int(len(frequent)*0.3)]  # upper bound of frequency for useful word
thr_l = -1  # frequent[int(len(frequent)*0.7)]  # lower bound of frequency for useful word
print(set(frequent))
print(thr_h)
print(thr_l)
word2idx = json.load(open("../word2idx", "r"))

info = json.load(open("texts.json"))

index = [[] for _ in range(len(info))]
inputs = []
idx = 0

for day in info:
    words = []  # all the appeared words in a day
    day_words = [set() for _ in range(len(day))]  # all the words in each article

    for article_idx in range(len(day)):
        article_words = {}
        for word in day[article_idx]:
            if thr_l < counter[word] < thr_h and word in word2idx.keys():  # useful word
                if word not in words:
                    words.append(word)
                    index[idx].append(word2idx[word])
                if word not in day_words[article_idx]:
                    day_words[article_idx].add(word)

    index[idx] = np.array(index[idx])

    d = [0 for _ in range(len(words))]
    d2 = [[0 for _ in range(len(words))] for _ in range(len(words))]
    for article_idx in range(len(day_words)):
        for word in day_words[article_idx]:
            d[words.index(word)] += 1
            for word2 in day_words[article_idx]:
                if word != word2:
                    d2[words.index(word)][words.index(word2)] += 1
    a_ = sp.lil_matrix((len(words), len(words)))
    for i in range(len(words)):
        for j in range(len(words)):
            if d2[i][j] != 0:
                if d2[i][j]*len(day)/d[i]/d[j] > 1:
                    a_[i, j] = np.log(d2[i][j]*len(day)/d[i]/d[j])
    inputs.append(a_)
    idx += 1

np.save("inputs", np.array(inputs))
np.save("index", np.array(index))



