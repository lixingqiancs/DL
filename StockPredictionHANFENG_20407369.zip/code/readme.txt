We use a famous word embedding text for all works. Generate it by:
0. Run wash_emb.py, you will get two files:
	word2idx: json file maps word (string) to its index (1~400000)
	stock.emb_100.npy: numpy file with 400000 vectors (100 each) indexed as word2idx


For each dataset, run as follow to get outputs
1. Run text.py, you will get two files:
	texts.json: cleaned text. 1989 (days) * 25 (top articles) and a list of word this article contains
	counter.json: counter for each words 

2. Run process.py, you will get two files:
	index.npy: numpy file for the index of words in each day
	inputs.npy: matrix A for each day

3. Run split.py, you will get six files for input. It split all instances into news of 7 days as  input->result for following day with training:test=8:2. You will get 6 files as input:
	THAD6h.idx.npy
	THAD6h.tidx.npy
	THAD6h.tx.npy
	THAD6h.ty.npy
	THAD6h.x.npy
	THAD6h.y.npy

For the visialization
4. Run graph_gen.py, you will get a json file 