import json
import numpy as np
import csv
import scipy.sparse as sp

inputs = np.load("inputs.npy", allow_pickle=True)
index = np.load("index.npy", allow_pickle=True)
new_input = []
new_index = []

print(inputs.shape)
print(index.shape)
for idx in range(len(index)-7):

    week_word = []
    transfer = [[0 for _ in range(len(index[idx+i]))] for i in range(7)]
    for i in range(7):
        for word_idx in range(len(index[idx+i])):
            word = index[idx+i][word_idx]
            if word not in week_word:
                transfer[i][word_idx] = len(week_word)
                week_word.append(word)
            else:
                transfer[i][word_idx] = week_word.index(word)
    new_index.append(np.array(week_word))
    info_7 = []
    for i in range(7):
        a_ = sp.lil_matrix((len(week_word), len(week_word)))
        for info in inputs[i+idx]:
            for row in range(len(info.rows)):
                for col_idx in range(len(info.rows[row])):
                    col = info.rows[row][col_idx]
                    a_[transfer[i][row], transfer[i][col]] = info.data[row][col_idx]
        info_7.append(a_)
    new_input.append(info_7)
new_input = np.array(new_input)
new_index = np.array(new_index)
print(new_index[0].shape)
print(new_input[0, 0].shape)

output = []
with open('../Combined_News_DJIA.csv')as f:
    f_csv = csv.reader(f)
    flag = True
    for row in f_csv:
        if flag:
            flag = False
            continue
        date_info = []  # all the articles in a day
        output.append([int(row[1])])
output = np.array(output)
order = np.arange(len(output)-7)
np.random.shuffle(order)

instance = []
label = []
index_ = []
for i in range(len(output)-7):
    #instance.append(inputs[i:i+7])
    label.append(output[i+7])
    #index_.append(index[i:i+7])

instance = np.array(new_input)[order]
label = np.array(label)[order]
index_ = np.array(new_index)[order]

thr = int(len(instance)*0.8)

np.save("THAD6h.idx", index_[:thr])
np.save("THAD6h.tidx", index_[thr:])
np.save("THAD6h.x", instance[:thr])
np.save("THAD6h.tx", instance[thr:])
np.save("THAD6h.y", label[:thr])
np.save("THAD6h.ty", label[thr:])
print(label.shape)

