import json
import numpy as np
import scipy.sparse as sp
counter = json.load(open("counter.json"))
frequent = list(counter.values())
frequent.sort()
thr_h = frequent[int(len(frequent)*0.95)]  # upper bound of frequency for useful word
thr_l = frequent[int(len(frequent)*0.05)]  # lower bound of frequency for useful word

word2idx = json.load(open("../word2idx", "r"))

info = json.load(open("texts.json"))

index = [[] for _ in range(len(info))]
inputs = []
idx = 0

for day in info:
    words = []  # all the appeared words in a day
    day_words = [set() for _ in range(len(day))]  # all the words in each article

    for article_idx in range(len(day)):
        article_words = {}
        for word in day[article_idx]:
            if thr_l < counter[word] < thr_h and word in word2idx.keys():  # useful word
                if word not in words:
                    words.append(word)
                    index[idx].append(word2idx[word])
                if word not in day_words[article_idx]:
                    day_words[article_idx].add(word)

    index[idx] = np.array(index[idx])

    d = [0 for _ in range(len(words))]
    d2 = [[0 for _ in range(len(words))] for _ in range(len(words))]
    for article_idx in range(len(day_words)):
        for word in day_words[article_idx]:
            d[words.index(word)] += 1
            for word2 in day_words[article_idx]:
                if word != word2:
                    d2[words.index(word)][words.index(word2)] += 1
    a_ = sp.lil_matrix((len(words), len(words)))
    for i in range(len(words)):
        for j in range(len(words)):
            if d2[i][j] != 0:
                if d2[i][j]*len(day)/d[i]/d[j] > 1:
                    a_[i, j] = np.log(d2[i][j]*len(day)/d[i]/d[j])
    inputs.append(a_)
    idx += 1
'''
day_words = [[set() for _ in range(len(day))] for day in info]
words = []
for day_idx in range(6):
    day = info[day_idx]
    for article_idx in range(len(day)):
        for word in day[article_idx]:
            if thr_l < counter[word] < thr_h and word in word2idx.keys():  # useful word
                if word not in words:
                    words.append(word)
                    index[idx].append(word2idx[word])
                if word not in day_words[article_idx]:
                    day_words[day_idx][article_idx].add(word)

for day_idx in range(len(info)-7):
    next_day = info[day_idx+6]

    for article_idx in range(len(next_day)):
        for word in next_day[article_idx]:
            if thr_l < counter[word] < thr_h and word in word2idx.keys():  # useful word
                if word not in words:
                    words.append(word)
                    index[idx].append(word2idx[word])
                if word not in day_words[article_idx]:
                    day_words[article_idx].add(word)
    if day_idx != 0:
        last_day = info[day_idx-1]
        for article_idx in range(len(last_day)):
            for word in last_day[article_idx]:
                if thr_l < counter[word] < thr_h and word in word2idx.keys():  # useful word
                    word_idx = words.index(word)
                    words.remove(word)
                    index[idx].pop(word2idx[word])
                    if word not in day_words[article_idx]:
                        day_words[article_idx].add(word)

    index[idx] = np.array(index[idx])

    d = [0 for _ in range(len(words))]
    d2 = [[0 for _ in range(len(words))] for _ in range(len(words))]
    for article_idx in range(len(day_words)):
        for word in day_words[article_idx]:
            d[words.index(word)] += 1
            for word2 in day_words[article_idx]:
                if word != word2:
                    d2[words.index(word)][words.index(word2)] += 1
    a_ = sp.lil_matrix((len(words), len(words)))
    for i in range(len(words)):
        for j in range(len(words)):
            if d2[i][j] != 0:
                if d2[i][j]*len(day)/d[i]/d[j] > 1:
                    a_[i, j] = np.log(d2[i][j]*len(day)/d[i]/d[j])
    inputs.append(a_)
    idx += 1
'''
np.save("inputs", np.array(inputs))
np.save("index", np.array(index))



