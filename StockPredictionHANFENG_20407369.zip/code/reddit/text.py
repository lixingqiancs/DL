import csv
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import json

ps = PorterStemmer()  # stemmer
word_all = {}  # the word and its frequency, saved for stop word generation
info = []  # dates*25->words
stop = set(stopwords.words('english'))

with open('Combined_News_DJIA.csv')as f:
    f_csv = csv.reader(f)
    flag = True
    counter = 0
    for row in f_csv:
        if flag:
            flag = False
            continue
        date_info = []  # all the articles in a day
        counter += 1
        print(counter)
        for body in row[2:]:
            article = []  # all the words in an article
            for word in body.strip("b").strip('"').lower().replace('|', '').replace(',', '')\
                    .replace('(', '').replace(')', '').replace(';', '').replace('?', '').replace('[', '')\
                    .replace(']', '').replace('!', '').replace('.', '').replace('-', '').replace('\n', ' ') \
                    .replace(':', '').replace("'", '').split():
                if word.isdigit() or word in stop:
                    continue
                word = ps.stem(word)
                article.append(word)
                if word not in word_all:
                    word_all[word] = 0
                word_all[word] += 1
            date_info.append(article)
        info.append(date_info)
json.dump(info, open("texts.json", "w"))
json.dump(word_all, open("counter.json", "w"))

